#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include<string.h>
#include <unistd.h>
int secretsize=0;
int exten_size=0;
/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_src_image)
{
	uint width, height;
	// Seek to 18th byte
	fseek(fptr_src_image, 18, SEEK_SET);

	// Read the width (an int)
	fread(&width, sizeof(int), 1,fptr_src_image);
	//printf("width = %u\n", width);

	// Read the height (an int)
	fread(&height, sizeof(int), 1,fptr_src_image);
	//printf("height = %u\n", height);

	// Return image capacity
	return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
	encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
	// Do Error handling
	if (encInfo->fptr_src_image == NULL)
	{
		perror("fopen");
		fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

		return e_failure;
	}
	encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
	if (encInfo->fptr_secret == NULL)
	{
		perror("fopen");
		fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

		return e_failure;
	}

	encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
	if (encInfo->fptr_stego_image == NULL)
	{
		perror("fopen");
		fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

		return e_failure;
	}
	return e_success;
}

unsigned int  sizeofextn(char *scerte_fname)
{
	char *ptr=strchr(scerte_fname,'.');
	if(ptr!=NULL)
	{

		return strlen(ptr);
	}
}

Status check_capacity(EncodeInfo *encInfo)
{
	// Step 1->find the size of source image file

	uint image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image);
	// step 2-> find the size of secrete file
	fseek(encInfo->fptr_secret,0,SEEK_END);
	secretsize=ftell(encInfo->fptr_secret);
	fseek(encInfo->fptr_secret,0,SEEK_SET);
	exten_size=sizeofextn(encInfo->secret_fname);
	uint image_secrte_capacity= 16+32+(sizeofextn(encInfo->secret_fname)*8)+32+(secretsize*8)+54;
	// step 4-> compare res and sizeof source file
	if(image_capacity>image_secrte_capacity)
	{
		return e_success;
	}
	else
	{
		return e_failure;
	}
	return e_unsupported;
}
Status copy_bmp_header(FILE *fptr_src_image,FILE *fptr_stego_image)
{
	char buffer[54];
	rewind(fptr_src_image);
	if(fread(buffer,54,1,fptr_src_image))
	{
		if(fwrite(buffer,54,1,fptr_stego_image))
		{
			return e_success;
		}
	}
	else
	{
		return e_failure;
	}

}
Status encode_data_to_image(char *data,FILE *fptr_src_image,FILE *fptr_stego_image)
{

	int n=strlen(data);
	char arr[8];
	int count=0;
	for(int i=0;i<n;i++)
	{
		fread(arr,8,1,fptr_src_image);
		encode_byte_of_lsb(arr,data[i]);
		fwrite(arr,8,1,fptr_stego_image);
		count++;

	}
	if(count==n)
	{
		return e_success;
	}
	return e_failure;

}
void encode_byte_of_lsb(char *arr,char ch)
{
	 char a;
	 for(int i=0;i<8;i++)
	 {
	     a= ch & (1<<i);
	     a=a>>i;
	     arr[i]=(arr[i] & (~(1)));
	     arr[i]=arr[i] | a;
	 }

}
Status encode_magic_string(char *magic_string,FILE *fptr_src_image,FILE *fptr_stego_image)
{
	encode_data_to_image(magic_string,fptr_src_image,fptr_stego_image);
}
void encode_size_to_lsb(char *ar,int n) // integer
{
	 int a;
	 for(int i=0;i<32;i++)
	 {
	     a= n & (1<<i);
	     a=a>>i;
	     ar[i]=(ar[i] & (~(1)));
	     ar[i]=ar[i] | a;
	 }
	

}
Status encode_secret_file_extn_size(int n,FILE *fptr_src_image,FILE *fptr_stego_image)
{
	char ar[32];
	fread(ar,32,1,fptr_src_image);
	encode_size_to_lsb(ar,n);
	fwrite(ar,32,1,fptr_stego_image);
	return e_success;
}
Status do_encoding(EncodeInfo *encInfo)
{
	char s[]=".txt";
	char s1[100];
	int index=0;
	FILE *fp=fopen("secret.txt","r");
	if(fp==NULL)
	{
		printf("file doesn't exist");
		return -1;
	}
	char c;
	for(;(c=fgetc(fp))!=EOF;)
	{
		s1[index++]=c;
	}
	s1[index-1] = '\0';
	if(open_files(encInfo)==e_success)
	{
		printf("Files are Opened\n");
		sleep(3);
		if((check_capacity(encInfo)==e_success))
		{
			printf("Check capacity done\n");
			sleep(3);
			if((copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image)==e_success))
			{
				printf("Copied_bmp_header file is done\n");
				sleep(3);
				if((encode_magic_string(MAGIC_STRING,encInfo->fptr_src_image,encInfo->fptr_stego_image))==e_success)
				{
					printf("Magic string encoded\n");
					sleep(3);
					if((encode_secret_file_extn_size(exten_size,encInfo->fptr_src_image,encInfo->fptr_stego_image))==e_success)
					{
						printf("Extn size is encoded\n");
						sleep(3);
						if((encode_data_to_image(s,encInfo->fptr_src_image,encInfo->fptr_stego_image))==e_success)
						{
							printf("Extension Data is Encoded\n");
							sleep(3);
							if((encode_secret_file_extn_size(secretsize,encInfo->fptr_src_image,encInfo->fptr_stego_image))==e_success)
							{
								printf("file size is Encoded\n");
								sleep(3);
								if((encode_data_to_image(s1,encInfo->fptr_src_image,encInfo->fptr_stego_image))==e_success)
								{
									printf("Tatal secrte file Data is Encoded\n");
									char ch;
									while(fread(&ch, 1, 1, encInfo -> fptr_src_image) != 0)
									{
										fwrite(&ch, 1, 1, encInfo -> fptr_stego_image);
									}
									fclose(encInfo -> fptr_stego_image);
									printf("Data is Extracted in text file is done\n");

								}
								return e_failure;
							}
							else
							{
								return e_failure;
							}

						}
						else
						{
							e_failure;
						}
					}
					else
					{
						return e_failure;
					}
				}
				else
				{
					return e_failure;
				}
			}
			else
			{
				return e_failure;
			}
		}
		else
		{
			return e_failure;
		}
	}
	else
	{
		return e_failure;
	}
}
