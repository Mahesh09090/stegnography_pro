#include "decode.h"
#include <stdio.h>
#include "types.h"
#include "common.h"
#include<string.h>
#include <unistd.h>
int ret=0;
static int ind=0;
char f[100];
static char res[100];

Status open_filesd(DecodeInfo *decInfo)
{
    // Open the source image file in read mode
    decInfo->fptr_source = fopen(decInfo->source_name, "r");
    
    // Error handling for source file
    if (decInfo->fptr_source == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->source_name);
        return e_failure;
    }
    return e_success;
}

Status decode_data_to_image(char *data,int n,FILE *fptr_source)
{
	char arr[8],s[100];
	int count=0;
	for(int i=0;i<n;i++)
	{
                    
		fread(arr, 8, 1, fptr_source);
		decode_byte_of_lsb(arr,s);
		count++;

	}
    if(strcmp(s,data)==0)
    {
        printf("Your Magic String is Matched\n");
        ind=0;
        return e_success;
    }
    else
    {
        printf("Your Entered Magic string is Not Matched\n");
        return e_failure;
    }
    return e_unsupported;

}

void decode_byte_of_lsb(char *arr,char *s)
{
	int res=0;
    int buff[8],rev[8];
	for(int i=0;i<8;i++)
	{
		arr[i]=(arr[i] & 1 );
		res=res & (1<<i);
		res=(res | arr[i]);
        buff[i]=res;
	}
    for(int i=0;i<8;i++)
    {
        rev[i]=buff[7-i];
    }
    char sum=0;
    for(int i=0;i<8;i++)
    {
        if(rev[7-i]==1)
        {
            int res=pow(2,i);
            sum+=res;
        }
    }
    s[ind++]=(char)sum;

}

Status decode_magic_string(char *magic_string,int n,FILE *fptr_source)
{
    fseek(fptr_source,54,SEEK_CUR);
	decode_data_to_image(magic_string,n,fptr_source);

}

int decode_size_to_lsb(char *ar) // integer
{
	int res=0;
    int buff[8],rev[8],index=0;
	for(int i=0;i<8;i++)
	{
		ar[i]=(ar[i] & 1 );
		res=res & (1<<i);
		res=(res | ar[i]);
        buff[i]=res;
	}
    for(int i=0;i<8;i++)
    {
        rev[i]=buff[7-i];
    }
    int sum=0;
    for(int i=0;i<8;i++)
    {
        if(rev[7-i]==1)
        {
            int res=pow(2,i);
            sum+=res;
        }
    }
    return sum;

}

Status decode_secret_file_extn_size(FILE *fptr_source)
{
	char ar[32];
	fread(ar,32,1,fptr_source);
	ret=decode_size_to_lsb(ar);
	return e_success;
}

Status decode_data_to_image_extn(int n,FILE *fptr_source)
{
    char arr[8],s[100];
	int count=0;
	for(int i=0;i<n;i++)
	{
                    
		fread(arr, 8, 1, fptr_source);
		decode_byte_of_lsb(arr,s);
		count++;

	}
    s[n]='\0';
    if(count==n)
    {
        ind=0;
        printf("Enter the File name : ");
        scanf("%s",f);
        strcat(f,s);
        return e_success;
    }
    return e_failure;
}


Status open_file(char *f,DecodeInfo *decInfo)
{
    if(strstr(f,".txt"))
    {
        decInfo->output_fname=f;
        decInfo->fptr_output= fopen(decInfo->output_fname, "w");
        if (decInfo->fptr_output == NULL)
        {
            perror("fopen");
            fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);
            return e_failure;
        }
        return e_success;
    }
    else
    {
        printf("Enter valid file name");
        return e_failure;
    }
}


Status decode_secret_file_size(FILE *fptr_source)
{
    char ar[32];
	fread(ar,32,1,fptr_source);
	ret=decode_size_to_lsb(ar);
	return e_success;

}
Status decode_data_to_image_secret_file(int n,FILE *fptr_source,FILE *fptr_output)
{
    char arr[8];
	int count=0;
	for(int i=0;i<n;i++)
	{
                    
		fread(arr, 8, 1, fptr_source);
		decode_byte_of_lsb(arr,res);
		count++;

	}
    res[n-1]='\0';
    if(count==n)
    {
        ind=0;
        return e_success;
    }
    return e_failure;
}



Status do_decoding(DecodeInfo *decInfo)
{
    if((open_files(decInfo)==e_success))
    {
        printf("Files are Opend \n");
        char s[2];
        printf("Enter the Magic String : ");
        scanf("%s",s);
        int n=strlen(s);
        if((decode_magic_string(s,n,decInfo->fptr_source)==e_success))
        {
            printf("Magic string is decoded\n");
            sleep(3);
            if((decode_secret_file_extn_size(decInfo->fptr_source)==e_success))
            {
                printf("file exten is decoded\n");
                sleep(3);
                if((decode_data_to_image_extn(ret,decInfo->fptr_source)==e_success))
                {
                    printf("image extension is decoded\n");
                    sleep(3);
                    if(open_file(f,decInfo)==e_success)
                    {
                        printf("opened text file\n");
                        sleep(3);
                        if((decode_secret_file_size(decInfo->fptr_source)==e_success))
                        {
                            printf("Decoded secrete file size\n");
                            sleep(3);
                            if((decode_data_to_image_secret_file(ret,decInfo->fptr_source,decInfo->fptr_output)==e_success))
                            {
                                printf("Decoded secrete file\n");
                                sleep(3);
                                int i = 0;
                                while (res[i] != '\0')  
                                {
                                    fwrite(&res[i], 1, 1, decInfo->fptr_output);
                                    i++;
                                }
                                fclose(decInfo->fptr_output);
                                printf("Totaly Secrete file is Decoded\n");
                            }

                        }
                        return e_failure;
                    }
                    return e_failure;

                }
                return e_failure;

            }
            return e_failure;

        }
        return e_failure;
    }
    return e_failure;

}