#include "types.h"
#include<stdio.h>
#include<math.h>
typedef struct _DecodeInfo
{
    char *source_name; // name
    FILE *fptr_source; // address

    char *output_fname;  // name
    FILE *fptr_output;

}DecodeInfo;

Status do_decoding(DecodeInfo *decInfo);
Status open_filesd(DecodeInfo *decInfo);
OperationType check_operation_type(char *argv);
Status decode_magic_string(char *magic_string,int n,FILE *fptr_source);
Status decode_data_to_image(char *data,int n,FILE *fptr_source);
void decode_byte_of_lsb(char *arr,char *s);
Status decode_secret_file_extn_size(FILE *fptr_source);
int decode_size_to_lsb(char *ar);
Status decode_data_to_image_extn(int ,FILE *fptr_source);
Status open_file(char *f,DecodeInfo *decInfo);
Status decode_secret_file_size(FILE *fptr_source);
Status decode_data_to_image_secret_file(int ,FILE *fptr_source,FILE *fptr_output);


