#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "decode.h"
#include <unistd.h>

int main(int argc,char *argv[])
{
    int val=check_operation_type(argv[1]);
    if(argv[1]==NULL) 
    {
        printf("ERROR : ./a.out : Invalid arguments \n");
        printf("Usage : ./a.out Enter -h for help or --h");
        return e_unsupported;

    } 
    else if((strcmp(argv[1],"-h")==0) || strcmp(argv[1],"--h")==0)
    {
        printf("For Encoding bmp File  :- ./a.out -e <bmp.file> <text.file> \n");
        printf("For Decoding bmp File  :- ./a.out -d <bmp.file>\n");
        return e_unsupported;
    }
    if(val==e_encode)
    {
       
        if(argv[2]==NULL)
        {
            printf("ERROR : ./a.out : Invalid arguments \n");
            printf("Usage : ./a.out Enter -h for help or --h\n");
            return e_unsupported;
        }
        if(argv[3]==NULL)
        {
            printf("ERROR : ./a.out : Invalid arguments \n");
            printf("Usage : ./a.out Enter -h for help or --h\n");
            return e_unsupported;
        }
        char *ret=strstr(argv[2],".bmp");
        if(ret==NULL)
        {
            printf("Please give bmp file\n");
            return e_unsupported;
        }
        char *rat=strstr(argv[3],".txt");
        if(rat==NULL)
        {
            printf("Please give .text file\n");
            return e_unsupported;
        }
        EncodeInfo encInfo;
        printf("Encoding is started\n");
        sleep(3);
        encInfo.src_image_fname=argv[2];
        encInfo.secret_fname=argv[3];
        if(argv[4]==NULL)
        {
            if (argc < 5 || argv[4] == NULL)
            {
              encInfo.stego_image_fname = "stego.bmp";
            } 
            else 
            {
                encInfo.stego_image_fname = argv[4];
            }
            encInfo.fptr_stego_image = fopen(encInfo.stego_image_fname, "w");
            if (encInfo.fptr_stego_image == NULL) {
                perror("fopen");
                fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo.stego_image_fname);
                return e_failure;
            }
        }
        do_encoding(&encInfo);

    }
    else if(val==e_decode)
    {
        if(argc==3)
        {
            if(argv[2]==NULL)
            {
                printf("ERROR : ./a.out : Invalid arguments \n");
                printf("Usage : ./a.out Enter -h for help or --h\n");
                return e_unsupported;
            }
            char *ret=strstr(argv[2],".bmp");
            if(ret==NULL)
            {
                printf("Please give bmp file\n");
                return e_unsupported;
            }
            printf("Decode is started\n");
            sleep(3);
            DecodeInfo decInfo;
            decInfo.source_name=argv[2];
            do_decoding(&decInfo);
        }
        else
        {
            printf("For Decoding bmp File  :- ./a.out -d <bmp.file>\n");
            return e_unsupported;    
        }

    }
    return 0;
}
OperationType check_operation_type(char *argv)
{
    if(!(strcmp(argv,"-e")))
    {
        return e_encode;
    }
    else if(!(strcmp(argv,"-d")))
    {
        return e_decode;
    }
    else
    {
        printf("ERROR : ./a.out : Invalid arguments \n");
        printf("Usage : ./a.out Enter -h for help or --h\n");
        return e_unsupported;
    }
}